window.dotify = {
  components: {},
  dataStore: {}
}