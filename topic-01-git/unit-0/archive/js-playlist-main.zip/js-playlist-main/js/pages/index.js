document.addEventListener('DOMContentLoaded', () => {
  const main = document.querySelector('main');
  const urlParams = new URLSearchParams(window.location.search);
  const onlyFavourites = urlParams.get('onlyFavourites') === 'true';
  dotify.dataStore.list().forEach((playlist) => {
    if(onlyFavourites) {
      const isFavourite = localStorage.getItem(playlist.name) === 'true';
      if(isFavourite) {
        main.innerHTML = main.innerHTML + dotify.components.createPlaylistItem(playlist);
      }
    } else {
      main.innerHTML = main.innerHTML + dotify.components.createPlaylistItem(playlist);
    }
  });

  const favouriteStyle = 'fa-solid fa-heart';
  const notFavouriteStyle = 'fa-regular fa-heart'
  document.querySelectorAll("[id^=fave-]").forEach(icon => {
    icon.addEventListener('click', (event) => {
      const iconElement = event.target;
      const playlistName = iconElement.id.replace('fave-','');
      const isAlreadyFavourite = localStorage.getItem(playlistName) === 'true';

      const isNowFavourite = !isAlreadyFavourite; // toggle the boolean value using !
      // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Conditional_operator
      // read below as
      // if isNowFavourite set the className to favouriteStyle, else set it to notFavouriteStyle
      icon.className = isNowFavourite ? favouriteStyle : notFavouriteStyle;
      console.log(`setting ${playlistName} to be a favourite - ${isNowFavourite}`);
      localStorage.setItem(playlistName, isNowFavourite);
    })
  });

  document.querySelectorAll("[id^=fave-]").forEach(icon => {
    const playlistName = icon.id.replace('fave-','');
    const isFavourite = localStorage.getItem(playlistName) === 'true';
    // if isFavourite, set className to 'favouriteStyle', else set it to 'notFavouriteStyle'
    icon.className = isFavourite ? favouriteStyle : notFavouriteStyle;
  });
});